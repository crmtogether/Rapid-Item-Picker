<%
Response.Clear();
Response.ContentType = "application/json";

var objar=new Array();//this stores our data objects

%>