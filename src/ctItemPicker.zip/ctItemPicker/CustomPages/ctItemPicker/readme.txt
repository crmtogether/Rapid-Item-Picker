
Notes:

1. Any file ending _json.asp returns json data.
2. the js folder has the 2 files needed for the js/custom folder to allow us create modals
3. 