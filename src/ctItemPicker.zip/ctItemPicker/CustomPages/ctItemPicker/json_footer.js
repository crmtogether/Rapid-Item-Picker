<%

Response.Write(createJSON(objar,CRM));
Response.End;


%>